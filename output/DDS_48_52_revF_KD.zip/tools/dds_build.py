#!/usr/bin/env python3
"""Generate the DDS 48-52 MHz KiCad project (rev F) from the design data.

    python3 tools/dds_build.py <project_dir> <revC_netlist.xml>

Writes into <project_dir>:
  lib/DDS.kicad_sym, lib/GOST_E3.kicad_wks, sym-lib-table,
  DDS_48_52.kicad_sch, 02_controller.kicad_sch, 03_power.kicad_sch,
  DDS_48_52.kicad_pro (schematic settings merged into an existing file),
  verification/refmap_revC_to_revF.json, keymap.json, expected_revF.json, eco_revF.json

Connectivity source of truth is the rev C netlist: every pin of the new
drawing takes its net from it (with the DIP-switch regrouping mapping), edited
by the rev E ECO (tools/eco.py: domestic regulators and logic).  The result is
checked by tools/netcompare.py against the intended rev F netlist and, for the
parts the ECO did not touch, against the rev C netlist.
"""
import json
import re
import sys
import xml.etree.ElementTree as ET
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
from kisch import q, suid, effects, f  # noqa: E402
from gost_symbols import build_library, write_library  # noqa: E402
from sheet import Sheet, POWER_NETS  # noqa: E402
from dds_parts import part, old_to_new, gost_prefix, PARTS  # noqa: E402
from gost_wks import write_wks  # noqa: E402
import eco  # noqa: E402
import eco_revF

PROJECT = 'DDS_48_52'
LIB = build_library()
INSTS = {}
TWO_PIN = {'R', 'C', 'L', 'L_Fe', 'F'}
NET = {}            # (key, pin) -> net name
SHEET_OF = {}       # key -> page

TB = dict(
    title='Синтезатор частоты 48–52 МГц',
    company='',
    rev='F',
    date='2026-11-06',
    c1='ХХХХ.ХХХХХХ.ХХХ Э3',
    c2='Схема электрическая принципиальная',
    c3='', c4='', c5='', c6='', c7='',
    c8='ЧЕРНОВИК — не для производства',
)


def load_netlist(path):
    root = ET.parse(path).getroot()
    for n in root.iter('net'):
        name = n.get('name')
        for x in n.iter('node'):
            key, unit, pin = old_to_new(x.get('ref'), x.get('pin'))
            NET[(key, pin)] = name
    eco.apply(NET)                       # rev E: domestic regulators and logic
    eco_revF.apply(NET)


# ---------------------------------------------------------------- helpers --

def put(sh, key, x, y, ang=0, unit=1, mirror=None, fields='auto', hide_value=False):
    p = part(key)
    sym = LIB[p['sym']]
    i = sh.place(key, sym, x, y, ang, unit, mirror)
    i.value = p['value']
    i.footprint = p['fp']
    i.dnp = p.get('dnp', False)
    i.in_bom = p.get('in_bom', sym.in_bom)
    i.extra['_hide_value'] = hide_value or key in ('DIP8', 'DIP4')
    for k_src, k_dst in (('tol', 'Допуск'), ('volt', 'Напряжение'), ('diel', 'ТКЕ'),
                         ('pwr', 'Мощность'), ('note', 'Примечание')):
        if p.get(k_src):
            i.extra[k_dst] = p[k_src]
    INSTS[(key, unit)] = i
    SHEET_OF[key] = sh.page
    place_fields(i, fields)
    return i


def place_fields(i, mode='auto'):
    name = i.sym.name
    x, y, a = i.x, i.y, i.ang % 360
    if mode != 'auto':
        i.ref_pos, i.val_pos = mode
        return
    if name in ('R', 'C', 'C_Pol', 'L', 'L_Fe'):
        if a in (0, 180):
            i.ref_pos = (x + 2.54, y - 0.635, 'left bottom')
            i.val_pos = (x + 2.54, y + 0.635, 'left top')
        else:
            h = 2.032 if name in ('C', 'C_Pol') else 1.651
            i.ref_pos = (x, y - h, 'bottom')
            i.val_pos = (x, y + h, 'top')
    elif name in ('VD_Schottky', 'F', 'SB', 'XW_Coax') or name.startswith('S_DIP'):
        if a in (0, 180):
            up = 3.81 if name.startswith('S_DIP') or name == 'SB' else 2.286
            if name == 'SB':
                up = 4.064
            i.ref_pos = (x, y - up, 'bottom')
            i.val_pos = (x, y + 2.032, 'top')
            if name == 'XW_Coax':
                i.ref_pos = (x, y - 2.286, 'bottom')
                i.val_pos = (x + 2.54, y + 2.54, 'left top')
        else:
            i.ref_pos = (x + 3.048, y - 0.635, 'left bottom')
            i.val_pos = (x + 3.048, y + 0.635, 'left top')
    elif name.startswith('X_'):
        dx = -2.54 if i.mirror == 'y' else 2.54
        n = len(i.sym.units[1]['pins'])
        i.ref_pos = (x + dx, y - 3.81, 'bottom')
        i.val_pos = (x + dx, y + (n - 0.5) * 5.08 + 1.27, 'top')
    else:   # ICs: origin at top-left of the frame
        W = i.sym.geom[i.unit]['W']
        H = i.sym.geom[i.unit]['H']
        i.ref_pos = (x + W / 2, y - 3.048, 'bottom')
        i.val_pos = (x + W / 2, y - 0.762, 'bottom')
        if i.unit != 1:
            i.val_pos = (x + W / 2, y + H + 0.762, 'top')
            i.extra['_hide_value'] = True


def term(sh, inst, pin, length=2.54):
    """Terminate a pin by its net: stub + power port / label, or a no-connect.
    For symmetric two-pin parts the termination is recorded by location and
    resolved after the orientation fix (pin numbers may still swap)."""
    if inst.sym.name in TWO_PIN and not getattr(sh, 'final', False):
        sh.deferred.append((inst, inst.pin_xy(pin), length))
        return
    key = (inst.key, str(pin))
    net = NET[key]
    if net.startswith('unconnected'):
        sh.nc(inst, pin)
        return
    (ex, ey), d = sh.stub(inst, pin, length)
    if net in POWER_NETS:
        sh.power(net, ex, ey, d)
    else:
        sh.label(net, ex, ey, d, kind='global' if is_global(net) else 'label')
    sh.done_pins.add(key)
    sh.term_pts.add(inst.pin_xy(pin))


def is_global(net):
    pages = {SHEET_OF.get(k) for (k, p), n in NET.items() if n == net}
    return len(pages) > 1


def wl(sh, net, x, y, d):
    """Label on an existing wire point."""
    if net in POWER_NETS:
        sh.power(net, x, y, d)
    else:
        sh.label(net, x, y, d, kind='global' if is_global(net) else 'label')


def autoterm(sh):
    """Called by the layout functions; real work happens in finish()."""
    sh.want_autoterm = True


def finish(sh):
    """After the orientation fix: resolve deferred terminations, then give every
    still unconnected pin a stub with its net label / power port / NC flag."""
    sh.final = True
    for inst, xy, length in sh.deferred:
        pin = next(p for p in inst.pins() if inst.pin_xy(p) == xy)
        term(sh, inst, pin, length)
    sh.split_wires()
    ends = set()
    for x1, y1, x2, y2 in sh.wires:
        ends.add((x1, y1)); ends.add((x2, y2))
    for i in sh.insts:
        for p in i.pins():
            xy = i.pin_xy(p)
            if xy in ends or xy in sh.term_pts or (i.key, p) in sh.done_pins:
                continue
            term(sh, i, p)


def row(origin_y, r):
    return origin_y + 5.08 * r


# ===================================================== sheet 3: power ====

def sheet_power(sh):
    Y = 60.96
    x4 = put(sh, 'J1', 35.56, Y, mirror='y')
    f1 = put(sh, 'F1', 50.8, Y)
    vd = put(sh, 'D1', 66.04, Y)
    sh.connect(x4, 1, f1, 1)
    sh.connect(f1, 2, vd, 2)
    g2 = x4.pin_xy(2)
    sh.pin_wire(x4, 2, (g2[0] + 7.62, g2[1]), (g2[0] + 7.62, g2[1] + 2.54))
    sh.power('GND', g2[0] + 7.62, g2[1] + 2.54, (0, 1))
    sh.flag(g2[0] + 5.08, g2[1], (0, -1))
    sh.text('+15 В ±5 %', 22.86, Y - 8.89, 1.524)
    sh.flag(73.66, Y, (0, 1))
    sh.label('VIN_PROT', 72.39, Y, (1, 0))

    # ---- DC/DC 1393ЕУ014: +15 В -> +5 В ------------------------------------
    x0 = 127.0
    d = put(sh, 'U3', x0, Y - 5.08)
    sh.pin_wire(d, '1', (72.39, Y))
    vb = x0 - 5.08                                 # VIN1..3 tied
    for p in ('2', '3'):
        sh.pin_wire(d, p, (vb, d.pin_xy(p)[1]))
    sh.wire((vb, Y), (vb, d.pin_xy('3')[1]))
    for ck, cx in (('C1', 78.74), ('C112', 88.9), ('C3', 99.06)):
        c = put(sh, ck, cx, Y + 5.08)
        sh.pin_wire(c, 1, (cx, Y))
        term(sh, c, 2, 0)
    # CL: current-limit resistor from VIN
    cl = d.pin_xy('6')
    rcl = put(sh, 'R101', x0 - 12.7, cl[1] - 5.08)
    top, bot = sorted(('1', '2'), key=lambda p: rcl.pin_xy(p)[1])
    sh.pin_wire(rcl, top, (x0 - 12.7, Y))
    sh.pin_wire(rcl, bot, cl)
    sh.wired_pins.add(('U3', '6'))
    # SS: R109 from VIN, C111 to GND
    ss = d.pin_xy('9')
    rss = put(sh, 'R109', x0 - 22.86, ss[1] - 5.08)
    top, bot = sorted(('1', '2'), key=lambda p: rss.pin_xy(p)[1])
    sh.pin_wire(rss, top, (x0 - 22.86, Y))
    sh.pin_wire(rss, bot, ss)
    sh.wired_pins.add(('U3', '9'))
    sh.wire((x0 - 22.86, ss[1]), (x0 - 27.94, ss[1]))
    css = put(sh, 'C111', x0 - 27.94, ss[1] + 2.54)
    sh.wired_pins.add(('C111', '1'))
    term(sh, css, 2, 0)
    # EXT: "universal" compensation R104 + C102 to GND
    ex = d.pin_xy('8')
    rc = put(sh, 'R104', ex[0] - 7.62, ex[1], ang=90)
    lp, rp = sorted(('1', '2'), key=lambda p: rc.pin_xy(p)[0])
    sh.pin_wire(rc, rp, ex)
    sh.wired_pins.add(('U3', '8'))
    cx = rc.pin_xy(lp)[0] - 5.08
    sh.pin_wire(rc, lp, (cx, ex[1]))
    cc = put(sh, 'C102', cx, ex[1] + 5.08)
    sh.pin_wire(cc, 1, (cx, ex[1]))
    term(sh, cc, 2, 0)
    # grounds
    gx = x0 - 5.08
    ys = []
    for p in ('5', '11', '12'):
        px, py = d.pin_xy(p)
        sh.pin_wire(d, p, (gx, py))
        ys.append(py)
    sh.wire((gx, min(ys)), (gx, max(ys) + 2.54))
    sh.power('GND', gx, max(ys) + 2.54, (0, 1))
    # switch node: SW1/SW2 tied, BST cap, catch diode, inductor
    sw = d.pin_xy('14')
    xr = sw[0]
    sh.pin_wire(d, '15', (xr + 2.54, d.pin_xy('15')[1]), (xr + 2.54, Y))
    sh.wired_pins.add(('U3', '14'))
    bst = d.pin_xy('4')
    cb = put(sh, 'C101', xr + 5.08, bst[1] - 2.54)
    top, bot = sorted(('1', '2'), key=lambda p: cb.pin_xy(p)[1])
    sh.pin_wire(cb, top, (xr + 5.08, Y))
    sh.pin_wire(d, '4', cb.pin_xy(bot))
    sh.wired_pins.add(('C101', bot))
    vd1 = put(sh, 'D101', xr + 15.24, Y + 3.81, ang=90)
    if vd1.pin_xy('1')[1] > vd1.pin_xy('2')[1]:
        vd1.ang = 270
    term(sh, vd1, '2', 0)
    sh.wired_pins.add(('D101', '1'))
    L = put(sh, 'L1', xr + 33.02, Y, ang=90)
    lp, rp = sorted(('1', '2'), key=lambda p: L.pin_xy(p)[0])
    sh.wire(sw, L.pin_xy(lp))
    sh.wired_pins.update({('L1', lp), ('U3', '14')})
    lo = L.pin_xy(rp)
    xe = lo[0] + 40.64
    sh.pin_wire(L, rp, (xe, Y))
    # feedback divider from the +5 V rail
    fb = d.pin_xy('10')
    nx = lo[0] + 2.54
    sh.pin_wire(d, '10', (nx, fb[1]))
    rup = put(sh, 'R102', nx, fb[1] - 5.08)
    top, bot = sorted(('1', '2'), key=lambda p: rup.pin_xy(p)[1])
    sh.pin_wire(rup, top, (nx, Y))
    sh.wired_pins.add(('R102', bot))
    rdn = put(sh, 'R103', nx, fb[1] + 5.08)
    term(sh, rdn, '2', 0)
    sh.wired_pins.add(('R103', '1'))
    for ck, dx in (('C2', 10.16), ('C103', 20.32), ('C104', 30.48)):
        co = put(sh, ck, lo[0] + dx, Y + 5.08)
        sh.pin_wire(co, 1, (co.x, Y))
        term(sh, co, 2, 0)
    sh.power('+5V', xe, Y, (0, -1))
    sh.flag(lo[0] + 35.56, Y, (0, -1))
    sh.text('U = 1,0 В·(1 + {R102}/{R103}) = 5,02 В; порог тока ≈ {R101}·0,5 мА/R(ключа) ≈ 1,6 А;', 116.84,
            17.78, 1.524)
    sh.text('плавный пуск ≈ 1,5 мс ({R109}, {C111}); коррекция «универсальная» ({R104}, {C102})', 116.84,
            22.86, 1.524)
    sh.text('PG {U3} — сброс МК до появления +5 В; вывод ON {U3} не подключён (включено)',
            116.84, 27.94, 1.524)

    # ---- LDO +3,3 В and +1,8 В from +5 В ------------------------------------
    def ldo(key, x, y, cin, cout, chf, out_net):
        u = put(sh, key, x, y - 5.08)
        pins = {p.name: p.num for p in u.sym.units[1]['pins']}
        pi, po, pg = pins['IN'], pins['OUT'], pins['GND']
        ix, iy = u.pin_xy(pi)
        sh.pin_wire(u, pi, (ix - 20.32, iy))
        sh.power('+5V', ix - 20.32, iy, (0, -1))
        c = put(sh, cin, ix - 10.16, iy + 5.08)
        sh.pin_wire(c, 1, (c.x, iy))
        term(sh, c, 2, 0)
        term(sh, u, pg)
        ox, oy = u.pin_xy(po)
        sh.pin_wire(u, po, (ox + 25.4, oy))
        for ck, dx in ((cout, 7.62), (chf, 17.78)):
            co = put(sh, ck, ox + dx, oy + 5.08)
            sh.pin_wire(co, 1, (co.x, oy))
            term(sh, co, 2, 0)
        sh.power(out_net, ox + 25.4, oy, (0, -1))
        return u
    ldo('U4', 266.7, Y, 'C105', 'C106', 'C107', '+3V3')
    ldo('U5', 266.7, Y + 45.72, 'C108', 'C109', 'C110', '+1V8')
    sh.text('LDO +3,3 В: AVDD/PVDD DDS, генератор, буфер SPI', 241.3, Y - 12.7, 1.524)
    sh.text('LDO +1,8 В: CVDD/DVDD DDS', 241.3, Y + 33.02, 1.524)
    # +3,3 V present -> MCU (DDS_PGOOD)
    r1 = put(sh, 'R1', 332.74, 157.48)
    term(sh, r1, 1)
    term(sh, r1, 2)
    sh.text('{R1}: признак наличия +3,3 В для МК (вход DDS_PGOOD)', 312.42, 144.78, 1.524)
    notes = [
        'Примечания',
        '1. Вход +15 В ±5 %; допустимое входное напряжение {U3} 9–20 В (порог UVLO 8,0/8,5 В).',
        '2. {D1} — защита от обратной полярности, {F1} — от перегрузки.',
        '3. Ёмкости керамических конденсаторов указаны эффективными при рабочем напряжении, X7R.',
        '4. Контур VIN–SW–{D101}–GND и {C1}, {C112}, {C3} — минимальной площади у выводов {U3}.',
        '5. Бюджет +5 В: {U5} до 0,4 А, {U4} до 0,15 А, МК и логика до 0,06 А — итого до 0,65 А.',
        '6. Рассеяние: {U5} до 1,3 Вт ((5 − 1,8) В · 0,4 А), {U4} до 0,26 Вт; {U3} с диодом ≈ 0,4 Вт.',
        '7. Корпуса {U3}–{U5}, {D101}, {L1} — посадочные места предварительные, уточнить по ТУ.',
    ]
    for k, t_ in enumerate(notes):
        sh.text(t_, 25.4, 160.02 + k * 5.08, 2.0 if k == 0 else 1.778)


# ================================================ sheet 2: controller ====

def sheet_controller(sh):
    X0, Y0 = 215.9, 30.48
    mcu = put(sh, 'U2', X0, Y0)
    # MCU left side: labels via auto-termination, PEN/RESET handled below
    # --- PEN pull-up and RESET network
    pen = mcu.pin_xy(1)
    r36 = put(sh, 'R36', pen[0] - 10.16, pen[1], ang=90)
    sh.connect(r36, 2, mcu, 1)
    term(sh, r36, 1)
    # --- right side: AREF cap, supply decoupling
    aref = mcu.pin_xy(62)
    c40 = put(sh, 'C40', aref[0] + 7.62, aref[1], ang=270)
    sh.connect(mcu, 62, c40, 2)
    term(sh, c40, 1, 0)
    # VCC pins with their capacitors
    vx = mcu.pin_xy(21)[0] + 5.08
    caps = {'21': 'C41', '52': 'C42', '64': 'C43'}
    ys = []
    for p, ck in caps.items():
        px, py = mcu.pin_xy(p)
        sh.pin_wire(mcu, p, (vx, py))
        c = put(sh, ck, vx + 7.62, py, ang=270, hide_value=True)
        sh.connect(c, 2, mcu, p, via=[(vx, py)]) if False else None
        sh.wire((vx, py), c.pin_xy(2))
        sh.wired_pins.add((ck, '2'))
        sh.wire(c.pin_xy(1), (vx + 15.24, py))
        sh.wired_pins.add((ck, '1'))
        ys.append(py)
    sh.wire((vx, min(ys)), (vx, max(ys)))
    sh.wire((vx, min(ys)), (vx, min(ys) - 2.54))
    sh.power('+5V', vx, min(ys) - 2.54, (0, -1))
    gys = []
    for p in ('22', '53', '63'):
        px, py = mcu.pin_xy(p)
        sh.pin_wire(mcu, p, (vx + 15.24, py))
        gys.append(py)
    sh.wire((vx + 15.24, min(ys)), (vx + 15.24, max(gys) + 5.08))
    sh.power('GND', vx + 15.24, max(gys) + 5.08, (0, 1))
    

    # --- DIP switch block (bits 0..11) -----------------------------------
    xa, xg = 35.56, 106.68
    y0 = 40.64
    rows = []
    for b in range(12):
        y = y0 + b * 10.16 + (5.08 if b >= 8 else 0)
        rows.append(y)
        rk = f'R{38 + b}'
        sk = f'SW{b + 1}'
        key, unit, _ = old_to_new(sk)
        r = put(sh, rk, xa + 7.62, y, ang=90)
        s = put(sh, key, xa + 50.8 - 15.24, y, unit=unit)
        nx = xa + 22.86
        sh.wire((xa, y), r.pin_xy(1)); sh.wired_pins.add((rk, '1'))
        sh.wire(r.pin_xy(2), (nx, y)); sh.wired_pins.add((rk, '2'))
        sh.wire((nx, y), s.pin_xy(old_to_new(sk, '1')[2])); sh.wired_pins.add((key, old_to_new(sk, '1')[2]))
        sh.wire(s.pin_xy(old_to_new(sk, '2')[2]), (xg, y)); sh.wired_pins.add((key, old_to_new(sk, '2')[2]))
        sh.wire((nx, y), (nx, y + 2.54))
        sh.label(f'DIP{b}', nx, y + 2.54, (1, 0))
    sh.wire((xa, rows[0] - 5.08), (xa, rows[-1]))
    sh.power('+5V', xa, rows[0] - 5.08, (0, -1))
    sh.wire((xg, rows[0]), (xg, rows[-1] + 5.08))
    sh.power('GND', xg, rows[-1] + 5.08, (0, 1))
    sh.text('{DIP8} — DIP-8 (биты 0–7), {DIP4} — DIP-4 (биты 8–11); подтяжки {' + ','.join(f'R{i}' for i in range(38, 50)) + '} 10 кОм', 30.48, rows[-1] + 10.16, 1.524)
    sh.text('Код частоты N = Σ бит·2^i; f = 48 000 000 + 1000·N Гц', 30.48, rows[-1] + 15.24, 1.524)
    sh.text('ВКЛ (замкнут) = 1 (программная инверсия); N = 0…4000, 4001…4095 отвергаются', 30.48,
            rows[-1] + 20.32, 1.524)

    # --- APPLY button, reset, ISP ---------------------------------------
    yb = rows[-1] + 40.64
    r50 = put(sh, 'R50', xa + 7.62, yb, ang=90)
    btn = put(sh, 'BTN', xa + 35.56, yb)
    nx = xa + 22.86
    sh.wire((xa, yb), r50.pin_xy(1)); sh.wired_pins.add(('R50', '1'))
    sh.power('+5V', xa, yb, (0, -1))
    sh.wire(r50.pin_xy(2), (nx, yb)); sh.wired_pins.add(('R50', '2'))
    sh.wire((nx, yb), btn.pin_xy(1)); sh.wired_pins.add(('BTN', '1'))
    sh.wire(btn.pin_xy(2), (xg, yb)); sh.wired_pins.add(('BTN', '2'))
    sh.power('GND', xg, yb, (0, 1))
    c44 = put(sh, 'C44', nx, yb + 7.62)
    sh.wire((nx, yb), c44.pin_xy(1)); sh.wired_pins.add(('C44', '1'))
    term(sh, c44, 2, 0)
    sh.wire((nx, yb), (nx, yb - 2.54))
    sh.label('APPLYn', nx, yb - 2.54, (1, 0))

    yr = yb + 30.48
    r37 = put(sh, 'R37', xa + 7.62, yr, ang=90)
    sh.wire((xa, yr), r37.pin_xy(1)); sh.wired_pins.add(('R37', '1'))
    sh.power('+5V', xa, yr, (0, -1))
    sh.wire(r37.pin_xy(2), (nx + 10.16, yr)); sh.wired_pins.add(('R37', '2'))
    c39 = put(sh, 'C39', nx, yr + 5.08)
    sh.wire((nx, yr), c39.pin_xy(1)); sh.wired_pins.add(('C39', '1'))
    term(sh, c39, 2, 0)
    sh.label('MCU_RESETn', nx + 10.16, yr, (1, 0), kind='global')

    isp = put(sh, 'J5', 314.96, 223.52)
    put(sh, 'J101', 215.9, 281.94)
    put(sh, 'TP101', 314.96, 281.94)
    put(sh, 'TP102', 314.96, 302.26)
    sh.text('{J101}: AVR JTAG / Atmel-ICE, 2x5, 1,27 мм', 350.52, 312.42, 1.524)
    sh.text('VTG = контроль +5 В; контакты 7 и 8 не подключать.', 350.52, 317.5, 1.524)
    sh.text('{J5}: площадки ISP; D3 отключён во время ISP.', 284.48, 327.66, 1.524)
    sh.text('{TP101}: внешний такт для восстановления; {TP102}: GND.', 284.48, 332.74, 1.524)
    # SPI level shifter block --------------------------------------------
    spi_block(sh)
    autoterm(sh)


def spi_block(sh):
    """MCU (5 V) -> DDS (3,3 V): 1564АП3 group 1 from +3,3 V with 1 кОм series
    resistors limiting the input clamp current; DDS SDO (3,3 V) -> MCU: two
    Schmitt inverters of 1594ТЛ2Т from +5 V (TTL thresholds)."""
    xb, y0 = 360.68, 35.56
    b = put(sh, 'U6', xb, y0, unit=1)
    chans = [  # A pin, series R (new), MCU-side pull, Y pin, output R, output pull
        ('2', 'R105', 'R64', '18', 'R51', 'R57'),
        ('4', 'R106', 'R65', '16', 'R52', 'R58'),
        ('6', 'R107', 'R63', '14', 'R53', 'R59'),
        ('8', 'R108', 'R62', '12', 'R54', 'R60'),
    ]
    for a_pin, rin, rpull, y_pin, rser, rout in chans:
        ax, ay = b.pin_xy(a_pin)
        # input: MCU label - pull - series R (1 кОм) - A
        rs_in = put(sh, rin, ax - 10.16, ay, ang=90)
        lp, rp = sorted(('1', '2'), key=lambda p: rs_in.pin_xy(p)[0])
        sh.pin_wire(rs_in, rp, (ax, ay))
        sh.wired_pins.add(('U6', a_pin))
        lx = rs_in.pin_xy(lp)[0]
        mcu_net = NET[(rin, '1')]
        sh.pin_wire(rs_in, lp, (lx - 33.02, ay))
        wl(sh, mcu_net, lx - 33.02, ay, (-1, 0))
        pu_in = NET[(rpull, '1')] == '+5V'
        px = lx - (25.4 if pu_in else 10.16)
        rpu = put(sh, rpull, px, ay - 7.62 if pu_in else ay + 7.62)
        if pu_in:
            sh.wire(rpu.pin_xy(2), (px, ay)); sh.wired_pins.add((rpull, '2'))
            term(sh, rpu, 1, 0)
        else:
            sh.wire(rpu.pin_xy(1), (px, ay)); sh.wired_pins.add((rpull, '1'))
            term(sh, rpu, 2, 0)
        # output: series R + pull + global label
        yx, yy = b.pin_xy(y_pin)
        rs = put(sh, rser, yx + 17.78, yy, ang=90)
        sh.connect(b, y_pin, rs, 1)
        sh.label(NET[('U6', y_pin)], yx + 12.7, yy, (-1, 0))
        ox = rs.pin_xy(2)[0]
        sh.pin_wire(rs, 2, (ox + 33.02, yy))
        wl(sh, NET[(rser, '2')], ox + 33.02, yy, (1, 0))
        up = NET[(rout, '1')] == '+3V3'
        ro = put(sh, rout, ox + (25.4 if up else 12.7), yy - 7.62 if up else yy + 7.62)
        if up:
            sh.wire(ro.pin_xy(2), (ro.x, yy)); sh.wired_pins.add((rout, '2'))
            term(sh, ro, 1, 0)
        else:
            sh.wire(ro.pin_xy(1), (ro.x, yy)); sh.wired_pins.add((rout, '1'))
            term(sh, ro, 2, 0)
    # EN (1OE#): BUF_OEn with pull-up to +3V3 (MCU pin in Hi-Z -> outputs off),
    # 1 кОм series resistor R110 to the 3,3 V input
    ex, ey = b.pin_xy('1')
    r110 = put(sh, 'R110', ex - 10.16, ey, ang=90)
    lp, rp = sorted(('1', '2'), key=lambda p: r110.pin_xy(p)[0])
    sh.pin_wire(r110, rp, (ex, ey))
    sh.wired_pins.add(('U6', '1'))
    lx = r110.pin_xy(lp)[0]
    sh.pin_wire(r110, lp, (lx - 25.4, ey))
    r61 = put(sh, 'R61', lx - 10.16, ey - 7.62)
    sh.wire(r61.pin_xy(2), (lx - 10.16, ey)); sh.wired_pins.add(('R61', '2'))
    term(sh, r61, 1, 0)
    wl(sh, 'BUF_OEn', lx - 25.4, ey, (-1, 0))
    # unused group 2 (2OE low: outputs off, inputs grounded) and supply unit
    put(sh, 'U6', xb, 147.32, unit=2)
    pw = put(sh, 'U6', xb - 2.54, 254.0, unit=3)
    c45 = put(sh, 'C45', xb - 15.24, 266.7)
    vx, vy = pw.pin_xy('20')
    sh.pin_wire(pw, '20', (c45.x, vy))
    sh.wire((c45.x, vy), c45.pin_xy(1)); sh.wired_pins.add(('C45', '1'))
    sh.wire((c45.x, vy), (c45.x - 7.62, vy))
    sh.power('+3V3', c45.x - 7.62, vy, (0, -1))
    term(sh, c45, 2, 0)
    # MISO path: DDS_SDO -> R55 -> SDO_BUF (R56) -> 1594ТЛ2Т x2 -> MCU_MISO
    ym = 297.18
    g1 = put(sh, 'U7', 431.8, ym - 5.08, unit=1)
    g2_ = put(sh, 'U7', 457.2, ym - 5.08, unit=2)
    ax, ay = g1.pin_xy('1')
    r55 = put(sh, 'R55', ax - 22.86, ay, ang=90)
    sh.pin_wire(r55, 1, (r55.pin_xy(1)[0] - 10.16, ay))
    wl(sh, 'DDS_SDO', r55.pin_xy(1)[0] - 10.16, ay, (-1, 0))
    sh.connect(r55, 2, g1, '1')
    sh.label(NET[('U7', '1')], ax - 5.08, ay, (-1, 0))
    r56 = put(sh, 'R56', ax - 12.7, ay + 7.62)
    sh.wire(r56.pin_xy(1), (r56.x, ay)); sh.wired_pins.add(('R56', '1'))
    term(sh, r56, 2, 0)
    sh.connect(g1, '2', g2_, '3')
    sh.label('SDO_INV', g1.pin_xy('2')[0] + 2.54, ay, (1, 0))
    for u, x in ((3, 360.68), (4, 391.16), (5, 421.64), (6, 452.12)):
        put(sh, 'U7', x, 330.2, unit=u)
    gp = put(sh, 'U7', 488.95, 330.2, unit=7)
    c46 = put(sh, 'C46', 476.25, 342.9)
    vx, vy = gp.pin_xy('14')
    sh.pin_wire(gp, '14', (c46.x, vy))
    sh.wire((c46.x, vy), c46.pin_xy(1)); sh.wired_pins.add(('C46', '1'))
    sh.wire((c46.x, vy), (c46.x - 7.62, vy))
    sh.power('+5V', c46.x - 7.62, vy, (0, -1))
    term(sh, c46, 2, 0)
    sh.text('Согласование уровней SPI 5 В → 3,3 В: {U6} от +3,3 В, на входах {R105,R106,R107,R108,R110} 1 кОм', 299.72, 16.51, 2.0)
    sh.text('(ограничение тока защитных диодов входов ≈ 1 мА); {U6} выключен при старте ({R61})',
            299.72, 20.32, 1.524)
    sh.text('SDO 3,3 В → 5 В: два инвертора {U7} (1594ТЛ2Т, ТТЛ-пороги) от +5 В', 381.0, 279.4, 1.524)
    sh.text('Свободные элементы {U6} (группа 2) и {U7}: входы на GND, выходы не подключены', 360.68, 320.04, 1.524)


# ====================================================== sheet 1: DDS ======

def sheet_dds(sh):
    X0, Y0 = 172.72, 30.48
    d1 = put(sh, 'U1', X0, Y0, unit=1)
    xp = d1.pin_xy(24)[0]          # left pin connection x
    xr = d1.pin_xy(43)[0]          # right pin connection x

    # ---- clock inputs ---------------------------------------------------
    clkp, clkm = d1.pin_xy(24), d1.pin_xy(23)
    r69 = put(sh, 'R69', xp - 10.16, clkp[1])
    r69.ref_pos = (r69.x - 2.54, r69.y - 0.635, 'right bottom'); r69.val_pos = (r69.x - 2.54, r69.y + 0.635, 'right top')
    sh.pin_wire(d1, 24, (xp - 5.08, clkp[1]), (xp - 5.08, r69.pin_xy(1)[1]), r69.pin_xy(1))
    sh.wired_pins.add(('R69', '1'))
    sh.pin_wire(d1, 23, r69.pin_xy(2))
    sh.wired_pins.add(('R69', '2'))
    sh.wire(r69.pin_xy(1), (xp - 20.32, r69.pin_xy(1)[1]))
    sh.label('CLKP', xp - 20.32, r69.pin_xy(1)[1], (-1, 0))
    sh.wire(r69.pin_xy(2), (xp - 20.32, clkm[1]))
    sh.label('CLKM', xp - 20.32, clkm[1], (-1, 0))

    cdp = d1.pin_xy(18)
    xw1 = put(sh, 'J2', 81.28, cdp[1], mirror='y')
    node = xw1.pin_xy(1)[0] + 12.7
    sh.pin_wire(xw1, 1, (node, cdp[1]))
    r70 = put(sh, 'R70', node, cdp[1] + 5.08)
    sh.wire((node, cdp[1]), r70.pin_xy(1)); sh.wired_pins.add(('R70', '1'))
    term(sh, r70, 2, 0)
    term(sh, xw1, 2, 0)
    c49 = put(sh, 'C49', node + 17.78, cdp[1], ang=90)
    sh.wire((node, cdp[1]), c49.pin_xy(1)); sh.wired_pins.add(('C49', '1'))
    sh.connect(c49, 2, d1, 18)
    sh.label(NET[('U1', '18')], c49.pin_xy(2)[0] + 2.54, cdp[1], (1, 0))
    sh.text('Вход 480 МГц, 0 дБм / 50 Ом', 60.96, cdp[1] - 10.16, 1.524)
    cdm = d1.pin_xy(19)
    c50 = put(sh, 'C50', xp - 12.7, cdm[1], ang=90)
    sh.connect(c50, 2, d1, 19)
    sh.label(NET[('U1', '19')], xp - 10.16, cdm[1], (1, 0))
    term(sh, c50, 1, 0)
    cs = d1.pin_xy(13)
    nx = xp - 25.4
    sh.pin_wire(d1, 13, (nx, cs[1]))
    sh.label(NET[('U1', '13')], nx + 7.62, cs[1], (1, 0))
    r71 = put(sh, 'R71', nx, cs[1] + 5.08)
    sh.wire((nx, cs[1]), r71.pin_xy(1)); sh.wired_pins.add(('R71', '1'))
    term(sh, r71, 2, 0)
    s1 = put(sh, 'DIP1', nx - 15.24, cs[1])
    sh.wire(s1.pin_xy(2), (nx, cs[1])); sh.wired_pins.add(('DIP1', '2'))
    term(sh, s1, 1, 0)
    sh.text('{DIP1} замкнут: такт с {J2} (CLKD); разомкнут: {G1} (CLKP/M)', 66.04, cs[1] + 15.24, 1.27)

    # ---- control / analog pins on the left --------------------------------
    # pull-ups of CS, RD, WR to +3V3 (rail)
    rail = xp - 27.94
    pu = [('8', 'R4'), ('76', 'R5'), ('77', 'R6')]
    ys = []
    for p, rk in pu:
        px, py = d1.pin_xy(p)
        r = put(sh, rk, xp - 12.7, py, ang=90, hide_value=True)
        sh.connect(r, 2, d1, p)
        sh.wire(r.pin_xy(1), (rail, py)); sh.wired_pins.add((rk, '1'))
        sh.label(NET[('U1', p)], xp - 7.62, py, (1, 0))
        ys.append(py)
    sh.wire((rail, min(ys) - 2.54), (rail, max(ys)))
    sh.power('+3V3', rail, min(ys) - 2.54, (0, -1))
    # pull-downs to a common GND rail: ADR, IREF1/2, CMP inputs, SEL1, SEL2
    grail = xp - 22.86
    pd = [('11', 'R7'), ('37', 'R2'), ('28', 'R3'), ('50', None), ('49', None)]
    pd += list(zip(['67', '68', '70', '71', '73', '74', '56', '57', '58', '59', '62', '63'],
                   [f'R{i}' for i in range(14, 20)] + [f'R{i}' for i in range(8, 14)]))
    gys = []
    for p, rk in pd:
        px, py = d1.pin_xy(p)
        if rk:
            r = put(sh, rk, xp - 12.7, py, ang=90, hide_value=True)
            sh.connect(r, 2, d1, p)
            sh.wire(r.pin_xy(1), (grail, py)); sh.wired_pins.add((rk, '1'))
            sh.label(NET[('U1', p)], xp - 7.62, py, (1, 0))
        else:
            sh.pin_wire(d1, p, (grail, py))
        gys.append(py)
    sh.wire((grail, min(gys)), (grail, max(gys) + 5.08))
    sh.power('GND', grail, max(gys) + 5.08, (0, 1))
    sh.text('{' + ','.join(f'R{i}' for i in range(8, 20)) + '} 100 кОм ±5 %', grail - 2.54, d1.pin_xy('63')[1] + 10.16, 1.27)
    sh.text('{R4,R5,R6} 10 кОм; {R7} 100 кОм; {R2,R3} 7,15 кОм ±0,1 %', grail - 2.54, d1.pin_xy('63')[1] + 13.97, 1.27)

    # ---- right side: DAC terminations, RF chain, data pull-downs ----------
    for p, rk in (('42', 'R73'), ('34', 'R74'), ('33', 'R75')):
        r = put(sh, rk, xr + 12.7, d1.pin_xy(p)[1], ang=270, hide_value=True)
        sh.connect(d1, p, r, 2)
        term(sh, r, 1, 0)
        sh.label(NET[('U1', p)], xr + 7.62, d1.pin_xy(p)[1], (-1, 0))
    rf_chain(sh, d1)
    dgr = xr + 22.86
    dys = []
    for i, p in enumerate(['78', '79', '80', '81', '83', '84', '87', '88', '89', '90', '92', '93',
                           '95', '96', '97', '98']):
        py = d1.pin_xy(p)[1]
        r = put(sh, f'R{20 + i}', xr + 12.7, py, ang=270, hide_value=True)
        sh.connect(d1, p, r, 2)
        sh.label(NET[('U1', p)], xr + 7.62, py, (-1, 0))
        sh.wire(r.pin_xy(1), (dgr, py)); sh.wired_pins.add((f'R{20 + i}', '1'))
        dys.append(py)
    sh.wire((dgr, min(dys)), (dgr, max(dys) + 5.08))
    sh.power('GND', dgr, max(dys) + 5.08, (0, 1))
    sh.text('{' + ','.join(f'R{i}' for i in range(20, 36)) + '} 100 кОм ±5 %', xr + 2.54, max(dys) + 10.16, 1.27)
    sh.text('{R72,R73,R74,R75} 49,9 Ом ±0,1 %', xr + 2.54, max(dys) + 13.97, 1.27)

    # ---- G1 oscillator cluster (unverified, DNP) --------------------------
    g1 = put(sh, 'G1', 66.04, 99.06)
    op, om = g1.pin_xy(4), g1.pin_xy(5)
    r67 = put(sh, 'R67', op[0] + 10.16, op[1], ang=90)
    r68 = put(sh, 'R68', om[0] + 10.16, om[1], ang=90)
    sh.connect(g1, 4, r67, 1)
    sh.connect(g1, 5, r68, 1)
    term(sh, r67, 2)
    term(sh, r68, 2)
    en = g1.pin_xy(1)
    r66 = put(sh, 'R66', en[0] - 5.08, en[1] - 5.08)
    sh.pin_wire(g1, 1, (en[0] - 5.08, en[1]))
    term(sh, r66, 1, 0)
    sh.wired_pins.add(('R66', '2'))
    sh.nc(g1, 2)
    vcc = g1.pin_xy(6)
    xs = [vcc[0] - 10.16, vcc[0] - 20.32]
    sh.pin_wire(g1, 6, (vcc[0] - 27.94, vcc[1]))
    for x, ck in zip(xs, ('C47', 'C48')):
        c = put(sh, ck, x, vcc[1] + 2.54)
        sh.wired_pins.add((ck, '1'))
        term(sh, c, 2, 0)
    sh.wire((vcc[0] - 27.94, vcc[1]), (vcc[0] - 27.94, vcc[1] - 2.54))
    sh.power('+3V3_OSC', vcc[0] - 27.94, vcc[1] - 2.54, (0, -1))
    gnd = g1.pin_xy(3)
    sh.pin_wire(g1, 3, (gnd[0] - 2.54, gnd[1]))
    sh.power('GND', gnd[0] - 2.54, gnd[1], (-1, 0))
    sh.text('{G1}, {R66,R67,R68} не устанавливаются: параметры и распиновка', 35.56, 142.24, 1.27)
    sh.text('ГК361-ТК-02 не подтверждены паспортом. Перед установкой', 35.56, 146.05, 1.27)
    sh.text('проверить корпус, выходы LVDS, EN, ток; затем разомкнуть {DIP1}.', 35.56, 149.86, 1.27)

    # ---- supply unit with decoupling --------------------------------------
    power_unit(sh)
    # ---- ferrite filters ----------------------------------------------------
    fb_block(sh)
    # ---- notes ---------------------------------------------------------------
    notes = [
        'Примечания',
        '1. Сплошной общий полигон земли; AGND, PGND, CGND, CMP_GND соединены на нём.',
        '2. Ток полной шкалы ЦАП IFS = 72 В / R = 10,07 мА ({R2}); напряжение на OUTP/OUTM не более ±0,6 В.',
        '3. ФНЧ — Баттерворт 7-го порядка, fср ≈ 70 МГц; номиналы округлены до E24.',
        '4. Уровень −10 дБм на 50 Ом устанавливается кодом амплитуды DDS при калибровке.',
        '5. Индуктивности {L4,L5,L6,L7} — ВЧ с высокой добротностью; проверить Q и SRF по моделям.',
        '6. Неиспользуемые выводы DATA, SEL — через резисторы на GND, не напрямую.',
        '7. Инициализация: ЦАП2 и компаратор выключены, SYNC/LINK выключены, профиль 0.',
        '8. Измерения SFDR и шумов не проводились; схема не является выпуском в производство.',
    ]
    for k, t in enumerate(notes):
        sh.text(t, 25.4, 300.0 + k * 5.08, 2.0 if k == 0 else 1.778)
    autoterm(sh)


def rf_chain(sh, d1):
    op = d1.pin_xy(43)
    y = op[1]
    x = op[0] + 20.32
    sh.pin_wire(d1, 43, (x, y))
    sh.label(NET[('U1', '43')], op[0] + 7.62, y, (-1, 0))
    r72 = put(sh, 'R72', x, y + 5.08)
    sh.wire((x, y), r72.pin_xy(1)); sh.wired_pins.add(('R72', '1'))
    term(sh, r72, 2, 0)
    c51 = put(sh, 'C51', x + 12.7, y, ang=90)
    sh.wire((x, y), c51.pin_xy(1)); sh.wired_pins.add(('C51', '1'))
    prev = c51.pin_xy(2)
    xx = prev[0]
    for lk, ck in (('L4', 'C52'), ('L5', 'C53'), ('L6', 'C54'), ('L7', None)):
        L = put(sh, lk, xx + 12.7, y, ang=90)
        sh.wire(prev, L.pin_xy(1)); sh.wired_pins.add((lk, '1'))
        n = L.pin_xy(2)[0] + 5.08
        sh.wire(L.pin_xy(2), (n, y)); sh.wired_pins.add((lk, '2'))
        if ck:
            c = put(sh, ck, n, y + 5.08)
            sh.wire((n, y), c.pin_xy(1)); sh.wired_pins.add((ck, '1'))
            term(sh, c, 2, 0)
        prev = (n, y)
        xx = n
    # pi attenuator
    r77 = put(sh, 'R77', xx, y + 7.62)
    sh.wire((xx, y), r77.pin_xy(1)); sh.wired_pins.add(('R77', '1'))
    term(sh, r77, 2, 0)
    r76 = put(sh, 'R76', xx + 10.16, y, ang=90)
    sh.wire((xx, y), r76.pin_xy(1)); sh.wired_pins.add(('R76', '1'))
    n2 = r76.pin_xy(2)[0] + 5.08
    sh.wire(r76.pin_xy(2), (n2, y)); sh.wired_pins.add(('R76', '2'))
    r78 = put(sh, 'R78', n2, y + 7.62)
    sh.wire((n2, y), r78.pin_xy(1)); sh.wired_pins.add(('R78', '1'))
    term(sh, r78, 2, 0)
    xw2 = put(sh, 'J3', n2 + 15.24, y)
    sh.wire((n2, y), xw2.pin_xy(1)); sh.wired_pins.add(('J3', '1'))
    term(sh, xw2, 2, 0)
    sh.text('ФНЧ 7-го порядка, fср ≈ 70 МГц', op[0] + 40.64, y - 10.16, 1.524)
    sh.text('Аттенюатор ≈1 дБ', xx - 2.54, y - 10.16, 1.524)
    sh.text('Выход 48–52 МГц, −10 дБм / 50 Ом', n2 + 7.62, y + 15.24, 1.524)


def power_unit(sh):
    X0, Y0 = 381.0, 76.2
    d = put(sh, 'U1', X0, Y0, unit=2)
    caps = {}
    for k in range(13, 35):
        v = None
    # decoupling map from rev C values "100n / U1.<pin>"
    cmap = {'1': 'C13', '9': 'C14', '14': 'C15', '15': 'C16', '16': 'C17', '21': 'C18', '26': 'C19',
            '27': 'C20', '30': 'C21', '31': 'C22', '36': 'C23', '39': 'C24', '40': 'C25', '45': 'C26',
            '47': 'C27', '51': 'C28', '60': 'C29', '61': 'C30', '69': 'C31', '75': 'C32', '82': 'C33',
            '94': 'C34'}
    bulk = {'+1V8': 'C35', '+3V3': 'C36', '+3V3_A': 'C37', '+1V8_Q': 'C38'}
    xp = d.pin_xy('1')[0]
    xr = xp - 5.08
    xg = xr - 15.24
    groups = {}
    for p in d.pins():
        px, py = d.pin_xy(p)
        if px == xp:
            groups.setdefault(NET[('U1', p)], []).append((py, p))
    allys = []
    for net, items in groups.items():
        items.sort()
        for py, p in items:
            sh.pin_wire(d, p, (xr, py))
            c = put(sh, cmap[p], xr - 7.62, py, ang=90, hide_value=True)
            sh.wire((xr, py), c.pin_xy(2)); sh.wired_pins.add((cmap[p], '2'))
            sh.wire(c.pin_xy(1), (xg, py)); sh.wired_pins.add((cmap[p], '1'))
            allys.append(py)
        top, bot = items[0][0], items[-1][0]
        sh.wire((xr, top), (xr, bot))
        yb = bot + 5.08
        cb = put(sh, bulk[net], xr - 7.62, yb, ang=90)
        sh.wire((xr, bot), (xr, yb))
        sh.wire((xr, yb), cb.pin_xy(2)); sh.wired_pins.add((bulk[net], '2'))
        sh.wire(cb.pin_xy(1), (xg, yb)); sh.wired_pins.add((bulk[net], '1'))
        allys.append(yb)
        sh.wire((xr, top), (xr, top - 5.08))
        sh.power(net, xr, top - 5.08, (0, -1))
    sh.wire((xg, min(allys)), (xg, max(allys) + 5.08))
    sh.power('GND', xg, max(allys) + 5.08, (0, 1))
    # ground pins on the right
    xgr = d.pin_xy('17')[0] + 5.08
    rys = []
    for p in d.pins():
        px, py = d.pin_xy(p)
        if px != xp:
            sh.pin_wire(d, p, (xgr, py))
            rys.append(py)
    sh.wire((xgr, min(rys)), (xgr, max(rys) + 5.08))
    sh.power('GND', xgr, max(rys) + 5.08, (0, 1))
    sh.text('{' + ','.join(f'C{i}' for i in range(13, 35)) + '} 0,1 мкФ — у выводов {U1},', xg - 12.7, max(allys) + 12.7, 1.27)
    sh.text('указанных в поле «Размещение»; {C35,C36,C37,C38} 10 мкФ', xg - 12.7, max(allys) + 16.51, 1.27)
    for p, ck in cmap.items():
        INSTS[(ck, 1)].extra['Размещение'] = f'у D1 выв. {p}'


def fb_block(sh):
    x0 = 266.7
    for k, (fb, c, src, dst) in enumerate((('FB1', 'C10', '+3V3', '+3V3_A'),
                                            ('FB2', 'C11', '+3V3', '+3V3_OSC'),
                                            ('FB3', 'C12', '+1V8', '+1V8_Q'))):
        y = 132.08 + k * 30.48
        L = put(sh, fb, x0 + 10.16, y, ang=90)
        sh.pin_wire(L, 1, (x0, y))
        sh.power(src, x0, y, (0, -1))
        n = L.pin_xy(2)[0] + 7.62
        sh.pin_wire(L, 2, (n + 10.16, y))
        cc = put(sh, c, n, y + 5.08)
        sh.wire((n, y), cc.pin_xy(1)); sh.wired_pins.add((c, '1'))
        term(sh, cc, 2, 0)
        sh.power(dst, n + 10.16, y, (0, -1))
        sh.flag(n + 5.08, y, (0, -1))
    sh.text('Фильтры питания DDS', x0 - 2.54, 116.84, 1.524)


# ======================================================= orientation fix ===



class UF:
    def __init__(self):
        self.p = {}

    def find(self, a):
        self.p.setdefault(a, a)
        while self.p[a] != a:
            self.p[a] = self.p[self.p[a]]
            a = self.p[a]
        return a

    def union(self, a, b):
        ra, rb = self.find(a), self.find(b)
        if ra != rb:
            self.p[ra] = rb


def drawn_components(sheets):
    uf = UF()
    pin_node = {}
    for sh in sheets:
        sh.split_wires()
        pg = sh.page
        for x1, y1, x2, y2 in sh.wires:
            uf.union((pg, x1, y1), (pg, x2, y2))
        for kind, net, x, y, d in sh.labels:
            uf.union((pg, x, y), ('G', net) if kind == 'global' else ('L', pg, net))
        for net, x, y, d in sh.powers:
            uf.union((pg, x, y), ('G', net))
        for i in sh.insts:
            for p in i.pins():
                xy = i.pin_xy(p)
                pin_node[(i.key, p, i.unit)] = (pg, xy[0], xy[1])
                uf.find((pg, xy[0], xy[1]))
    return uf, pin_node


def fix_orientation(sheets):
    """Rotate symmetric two-pin parts by 180 deg where the drawing connected
    them the other way round, so pin numbers match the reference netlist.
    Evidence comes from IC pins, labels and power ports, then from two-pin
    parts already settled (for chains such as the RF filter)."""
    settled = set()
    for _ in range(12):
        uf, pin_node = drawn_components(sheets)
        prev = set(settled)
        two = {i.key for sh in sheets for i in sh.insts if i.sym.name in TWO_PIN}
        comp = {}
        for (k, p, u), node in pin_node.items():
            comp.setdefault(uf.find(node), []).append((k, p))
        named = {}
        for node in list(uf.p):
            if node[0] in ('G', 'L'):
                named.setdefault(uf.find(node), set()).add(node[-1])

        def expected(root, exclude):
            nets = {NET[m] for m in comp.get(root, [])
                    if m[0] != exclude and m in NET and (m[0] not in two or m[0] in prev)}
            return nets | named.get(root, set())
        changed = 0
        for sh in sheets:
            for i in sh.insts:
                if i.sym.name not in TWO_PIN or i.key in settled:
                    continue
                r1 = uf.find(pin_node[(i.key, '1', 1)])
                r2 = uf.find(pin_node[(i.key, '2', 1)])
                e1, e2 = expected(r1, i.key), expected(r2, i.key)
                if not e1 and not e2:
                    continue
                n1, n2 = NET[(i.key, '1')], NET[(i.key, '2')]
                ok = (not e1 or n1 in e1) and (not e2 or n2 in e2)
                swapped = (not e1 or n2 in e1) and (not e2 or n1 in e2)
                if not ok and swapped:
                    i.ang = (i.ang + 180) % 360
                settled.add(i.key)
                changed += 1
        if not changed:
            return


# ================================================================ output ===

def annotate(sheets):
    """GOST 2.702: number within each letter code in sheet order, top to bottom
    within columns from left to right (column width 25.4 mm)."""
    first = {}
    for sh in sheets:
        for i in sh.insts:
            k = i.key
            pos = (int(sh.page), round(i.x // 25.4), i.y, i.x)
            if k not in first or pos < first[k]:
                first[k] = pos
    by = {}
    for k, pos in first.items():
        by.setdefault(gost_prefix(k), []).append((pos, k))
    # Preserve every existing reference, including X2 on the power sheet.
    refs = json.loads((Path(__file__).resolve().parent.parent / 'verification' /
                       'keymap_revE.json').read_text(encoding='utf-8'))
    refs.update(eco_revF.NEW_REFS)
    assert set(refs) == set(first), (set(refs) - set(first), set(first) - set(refs))
    for sh in sheets:
        for i in sh.insts:
            i.ref = refs[i.key]
    return refs


def compact(refs):
    """['R13','R14','R15','R20'] -> 'R13–R15, R20'"""
    def k(r):
        m = re.match(r'([A-Z]+)(\d+)', r)
        return m.group(1), int(m.group(2))
    items = sorted(set(refs), key=k)
    out, i = [], 0
    while i < len(items):
        p, n = k(items[i]); j = i
        while j + 1 < len(items) and k(items[j + 1]) == (p, n + (j + 1 - i)):
            j += 1
        if j - i >= 2:
            out.append(f'{items[i]}–{items[j]}')
        else:
            out.extend(items[i:j + 1])
        i = j + 1
    return ', '.join(out)


def make_resolver(refs):
    def res(s):
        def rep(m):
            keys = m.group(1).split(',')
            return compact([refs[k.strip()] for k in keys])
        return re.sub(r'\{([A-Z0-9_,\s]+)\}', rep, s)
    return res


def title_block(sh):
    t = TB
    return (f'(title_block (title {q(t["title"])}) (date {q(t["date"])}) (rev {q(t["rev"])}) '
            f'(company {q(t["company"])}) (comment 1 {q(t["c1"])}) (comment 2 {q(t["c2"])}) '
            f'(comment 3 {q(t["c3"])}) (comment 4 {q(t["c4"])}) (comment 5 {q(t["c5"])}) '
            f'(comment 6 {q(t["c6"])}) (comment 7 {q(t["c7"])}) (comment 8 {q(t["c8"])}) '
            f'(comment 9 {q(sh.title)}))')


def sheet_symbol(root, child, x, y, w, h):
    return (f'(sheet (at {f(x)} {f(y)}) (size {f(w)} {f(h)}) (exclude_from_sim no) (in_bom yes) '
            f'(on_board yes) (dnp no) (stroke (width 0.1524) (type solid)) (fill (color 0 0 0 0)) '
            f'(uuid "{child.sheet_path_uuid}") '
            f'(property "Sheetname" {q(child.title)} (at {f(x)} {f(y - 0.762)} 0) {effects(1.524, "left bottom")}) '
            f'(property "Sheetfile" {q(child.file)} (at {f(x)} {f(y + h + 0.762)} 0) {effects(1.27, "left top")}) '
            f'(instances (project {q(PROJECT)} (path "/{root.uuid}" (page {q(child.page)})))))')


def main(out_dir, base_netlist):
    out = Path(out_dir)
    load_netlist(base_netlist)
    s1 = Sheet('dds', 'DDS_48_52.kicad_sch', 'A2', 'DDS, тактирование, выход', '1', 'dds')
    s2 = Sheet('ctl', '02_controller.kicad_sch', 'A2', 'Контроллер', '2', 'ctl')
    s3 = Sheet('pwr', '03_power.kicad_sch', 'A3', 'Питание', '3', 'pwr')
    s1.uuid = suid('root:dds')
    for sh in (s1, s2, s3):
        sh.deferred, sh.term_pts = [], set()
    for sh in (s2, s3):
        sh.sheet_path_uuid = suid('sheetsym:' + sh.name)
    # pages must be known before layout (global/local label decision)
    for k in list(PARTS) + ['DIP8', 'DIP4', 'DIP1', 'BTN']:
        pass
    pre_pages(s1, s2, s3)
    sheet_dds(s1)
    sheet_controller(s2)
    sheet_power(s3)
    s1.sheet_syms.append(sheet_symbol(s1, s2, 25.4, 375.92, 50.8, 10.16))
    s1.sheet_syms.append(sheet_symbol(s1, s3, 86.36, 375.92, 50.8, 10.16))
    fix_orientation([s1, s2, s3])
    for sh in (s1, s2, s3):
        finish(sh)
    refs = annotate([s1, s2, s3])
    res = make_resolver(refs)
    for sh in (s1, s2, s3):
        sh.resolve = res
    # placement notes now that D1 is known
    (out / 'lib').mkdir(exist_ok=True)
    write_library(LIB, out / 'lib' / 'DDS.kicad_sym')
    write_wks(out / 'lib' / 'GOST_E3.kicad_wks')
    for sh in (s1, s2, s3):
        (out / sh.file).write_text(sh.sexpr(PROJECT, s1.uuid, LIB, title_block(sh)), encoding='utf-8')
    # symbol library table
    (out / 'sym-lib-table').write_text(
        '(sym_lib_table\n  (version 7)\n'
        '  (lib (name "DDS")(type "KiCad")(uri "${KIPRJMOD}/lib/DDS.kicad_sym")(options "")'
        '(descr "DDS project symbols, ESKD style"))\n)\n', encoding='utf-8')
    # project settings
    pro_path = out / f'{PROJECT}.kicad_pro'
    try:
        pro = json.loads(pro_path.read_text(encoding='utf-8'))
    except Exception:
        pro = {}
    pro.setdefault('meta', {'filename': f'{PROJECT}.kicad_pro', 'version': 3})
    sch = pro.setdefault('schematic', {})
    sch['subpart_id_separator'] = 46      # '.'  -> D3.1
    sch['subpart_first_id'] = 49          # '1'
    sch['page_layout_descr_file'] = '${KIPRJMOD}/lib/GOST_E3.kicad_wks'
    pro['sheets'] = [[s1.uuid, 'Root'], [s2.sheet_path_uuid, s2.title], [s3.sheet_path_uuid, s3.title]]
    pro.setdefault('text_variables', {})
    pro_path.write_text(json.dumps(pro, indent=2, ensure_ascii=False), encoding='utf-8')
    # rev C -> rev E designator map for verification
    refmap = {}
    import xml.etree.ElementTree as ET2
    for c in ET2.parse(base_netlist).getroot().iter('comp'):
        old = c.get('ref')
        key, unit, _ = old_to_new(old)
        if key not in refs:                     # removed by the rev E ECO
            continue
        if key == old:
            refmap[old] = refs[key]
        else:
            pins = {p: old_to_new(old, p)[2] for p in ('1', '2')}
            refmap[old] = {'ref': refs[key], 'pins': pins}
    (out / 'verification').mkdir(exist_ok=True)
    (out / 'verification' / 'keymap.json').write_text(
        json.dumps(refs, indent=1, ensure_ascii=False, sort_keys=True), encoding='utf-8')
    (out / 'verification' / 'refmap_revC_to_revF.json').write_text(
        json.dumps(refmap, indent=1, ensure_ascii=False, sort_keys=True), encoding='utf-8')
    # rev E intended connectivity (rev C netlist + ECO) and the parts the ECO touched
    exp = {}
    for (k, p), n in NET.items():
        if k in refs:
            exp.setdefault(n, []).append([refs[k], p])
    (out / 'verification' / 'expected_revF.json').write_text(
        json.dumps({n: sorted(v) for n, v in sorted(exp.items())}, indent=1, ensure_ascii=False),
        encoding='utf-8')
    previous = {k: v for k, v in refs.items() if k not in eco_revF.NEW_REFS}
    changed = {'revE': ['D2'], 'revF': ['D2', *sorted(eco_revF.NEW_REFS.values())],
               'value_or_footprint_changed': ['X1', 'L8'], 'mcu_pins': eco_revF.MCU_PINS}
    (out / 'verification' / 'eco_revF.json').write_text(json.dumps(changed, indent=1), encoding='utf-8')
    (out / 'verification' / 'refmap_revE_to_revF.json').write_text(
        json.dumps({v: v for v in sorted(previous.values())}, indent=1), encoding='utf-8')
    print('written; parts:', len(refs))


def pre_pages(s1, s2, s3):
    """Assign pages to keys before drawing (needed to decide local/global labels)."""
    ctl = {'U2', 'U6', 'U7', 'J5', 'DIP8', 'DIP4', 'BTN'} | {f'R{i}' for i in range(36, 66)} \
        | {f'C{i}' for i in range(39, 47)}
    ctl |= {'R105', 'R106', 'R107', 'R108', 'R110', *eco_revF.NEW_REFS}
    pwr = {'J1', 'F1', 'D1', 'U3', 'U4', 'U5', 'L1', 'R1', 'C1', 'C2', 'C3', 'D101'} \
        | {f'C{i}' for i in range(101, 113)} | {'R101', 'R102', 'R103', 'R104', 'R109'}
    for (k, p) in NET:
        SHEET_OF[k] = '2' if k in ctl else '3' if k in pwr else '1'


if __name__ == '__main__':
    main(sys.argv[1], sys.argv[2])
