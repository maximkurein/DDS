#!/bin/sh
# Release outputs from the KiCad project (run inside the KiCad environment).
#   tools/make_outputs.sh <project_dir> [<word_template.docx>]   (KiCad paths: tools/env.sh)
# Schematic PDF, BOM, netlist, ERC/DRC reports, board PDF, JLCPCB fabrication
# set (Gerber + Excellon + BOM/CPL), Visio Э3 and Word ПЭ3.
set -e
P=$(cd "$1" && pwd); T=$(cd "$(dirname "$0")" && pwd)
. "$T/env.sh"
TPL=${2:-"$T/templates/ПЭ3_форма_А4.docx"}
cd "$P"
mkdir -p output/pdf output/bom output/netlist output/visio output/docs reports
SCH=DDS_48_52.kicad_sch; PCB=DDS_48_52.kicad_pcb

# --- schematic
"$KICAD_CLI" sch export netlist --format kicadxml -o output/netlist/netlist.xml $SCH
"$KICAD_CLI" sch export pdf -o output/pdf/DDS_48_52_sch.pdf $SCH >/dev/null
"$KICAD_CLI" sch export bom -o output/bom/BOM.csv \
  --fields 'Reference,Value,Footprint,Допуск,Мощность,Напряжение,ТКЕ,Примечание,${QUANTITY},${DNP}' \
  --labels 'Поз. обозначение,Номинал,Посадочное место,Допуск,Мощность,Напряжение,ТКЕ,Примечание,Кол.,Не устанавливать' \
  --group-by 'Value,Footprint,Допуск,Мощность,Напряжение,ТКЕ,Примечание,${DNP}' --ref-range-delimiter '-' $SCH >/dev/null
"$KICAD_CLI" sch erc --severity-all -o reports/ERC.rpt $SCH | tail -1

# --- board
"$KICAD_CLI" pcb drc --schematic-parity --severity-all -o reports/DRC.rpt $PCB | tail -1
"$KICAD_CLI" pcb export pdf --mode-multipage --include-border-title --drill-shape-opt 1 --scale 2 \
  -l F.Cu,In1.Cu,In2.Cu,B.Cu,F.Silkscreen,F.Fab --cl Edge.Cuts -o output/pdf/DDS_48_52_pcb.pdf $PCB >/dev/null

# --- JLCPCB fabrication set
J=output/jlcpcb; rm -rf $J/gerber; mkdir -p $J/gerber
"$KICAD_CLI" pcb export gerbers --no-x2 --no-netlist --subtract-soldermask \
  -l F.Cu,In1.Cu,In2.Cu,B.Cu,F.Paste,B.Paste,F.Silkscreen,B.Silkscreen,F.Mask,B.Mask,Edge.Cuts \
  -o $J/gerber/ $PCB >/dev/null
"$KICAD_CLI" pcb export drill --format excellon --excellon-units mm --excellon-zeros-format decimal \
  --excellon-oval-format alternate --excellon-separate-th --drill-origin absolute \
  --generate-map --map-format gerberx2 -o $J/gerber/ $PCB >/dev/null
(cd $J/gerber && rm -f ../DDS_48_52_gerber.zip && "$KPY" -c "
import zipfile, os
with zipfile.ZipFile('../DDS_48_52_gerber.zip', 'w', zipfile.ZIP_DEFLATED) as z:
    for f in sorted(os.listdir('.')):
        if 'drl_map' not in f:            # drill maps are for review only
            z.write(f)
    print('gerber zip:', len(z.namelist()), 'files')")
"$KICAD_CLI" pcb export pos --format csv --units mm --side both --exclude-dnp -o $J/pos_kicad.csv $PCB >/dev/null
"$KPY" "$T/jlc_bom_cpl.py" output/netlist/netlist.xml $J/pos_kicad.csv $J
# order request texts (RU/EN) for a PCB-only order; parameters: docs/order_params.json, quantity: ORDER_QTY=10 sh tools/make_outputs.sh .
"$KPY" "$T/order_txt.py" $PCB docs/order_params.json $J ${ORDER_QTY:+--qty $ORDER_QTY}

# --- demonstration documents (Visio Э3, Word ПЭ3): need pip packages vsdx, python-docx, pillow
if ! "$KPY" -c "import vsdx, docx, PIL" 2>/dev/null; then
  echo "Visio/Word: python packages vsdx, python-docx, pillow missing - skipped"; exit 0
fi
"$KPY" "$T/sch2vsdx.py" "$P" "output/visio/DDS_48_52_revF_Э3_150.vsdx" --scale-150 | tail -1
if [ -f "$TPL" ]; then
  "$KPY" "$T/pe3_docx.py" output/netlist/netlist.xml "$TPL" "output/docs/DDS_48_52_revF_ПЭ3.docx"
else
  echo "ПЭ3: template not found ($TPL) - skipped"
fi
